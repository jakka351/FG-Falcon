// CAN_DownloadDlg.h : header file
//

#if !defined(AFX_CAN_DOWNLOADDLG_H__EB3A5BA1_901E_42E1_B70D_1094B3738219__INCLUDED_)
#define AFX_CAN_DOWNLOADDLG_H__EB3A5BA1_901E_42E1_B70D_1094B3738219__INCLUDED_

#include "UnlockDlg.h"	// Added by ClassView
#include "CANSetupDlg.h"	// Added by ClassView
#include "UcanIntf.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCAN_DownloadDlg dialog

class CCAN_DownloadDlg : public CDialog
{
// Construction
public:

	CCAN_DownloadDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCAN_DownloadDlg)
	enum { IDD = IDD_CAN_DOWNLOAD_DIALOG };
	CEdit	m_ctlFileDisplay;
	CProgressCtrl	m_ctlProgress;
	CStatic	m_ctlDownloading;	//CSS
	CButton	m_cFileDownload;
	CString	m_sFileDisplay;
	CString	m_sStatus;	//CSS
	BOOL status_line1_written;	//CSS

	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCAN_DownloadDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCAN_DownloadDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnFileopen();
	afx_msg void OnFiledownload();
	afx_msg void OnCanSetup();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_iDataOffset;
	int m_iCurrLineBytesRemaining;
	char m_sLine[80];
	int m_iNextLine;
	BOOL m_bDownloadEnable;
	BOOL m_bUnlock;
	WORD m_iCANBitRate;
	LONG m_lCANBitRate;	//Added CSS
	BYTE m_iCANIDFormat;
	DWORD m_iCANID;
	BOOL TransferFile();
	int m_sLineCount;
	LRESULT OnUcanReceive(WPARAM UcanHandle_p, LPARAM);
	LRESULT OnUcanFatalDisconnect(WPARAM UcanHandle_p, LPARAM);
	LRESULT OnUcanStatus(WPARAM UcanHandle_p, LPARAM);
	BOOL m_fInitOk;
	CUcanIntf* m_pUsbCanModul;
	CCANSetupDlg m_dCANSetupDlg;
	CUnlockDlg m_dUnlockDlg;
	afx_msg void OnBnClickedAboutButton();
	afx_msg void OnStnClickedStatus();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAN_DOWNLOADDLG_H__EB3A5BA1_901E_42E1_B70D_1094B3738219__INCLUDED_)

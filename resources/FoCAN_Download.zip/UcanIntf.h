// UcanIntf.h: Schnittstelle f�r die Klasse CUcanIntf.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UCANINTF_H__FCEBA8AA_65BF_4188_9969_46A8A106B4D4__INCLUDED_)
#define AFX_UCANINTF_H__FCEBA8AA_65BF_4188_9969_46A8A106B4D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Usbcan32.h"

#define WM_UCAN_RECEIVE             (WM_USER + 1)
#define WM_UCAN_STATUS              (WM_USER + 2)
#define WM_UCAN_CONNECT             (WM_USER + 10)
#define WM_UCAN_DISCONNECT          (WM_USER + 11)
#define WM_UCAN_FATAL_DISCONNECT    (WM_USER + 12)

class CUcanIntf
{
public:
	CUcanIntf(CWnd*);
	BOOL Initialize (BYTE bDeviceNr_p, WORD wBTR_p, LONG m_lCANBitRate);
    tUcanHandle GetHandle ();
	BOOL GetHwInfo (tUcanHardwareInfo* pUcanHwInfo_p);
	BOOL ReadMsg (tCanMsgStruct* pCanMsg_p);
    BOOL WriteMsg (tCanMsgStruct *pCanMsg_p);
	BOOL GetStatus (WORD* pwStatus_p);
	BOOL Reset ();
	BOOL ShutDown ();
	virtual ~CUcanIntf();

protected:
    BOOL        m_fIsInitialized;
    tUcanHandle m_UcanHandle;

};

#endif // !defined(AFX_UCANINTF_H__FCEBA8AA_65BF_4188_9969_46A8A106B4D4__INCLUDED_)

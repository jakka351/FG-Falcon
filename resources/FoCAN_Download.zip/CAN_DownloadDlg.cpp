// CAN_DownloadDlg.cpp : implementation file

#include "stdafx.h"
#include "CAN_Download.h"
#include "UnlockDlg.h"
#include "CANSetupDlg.h"
#include "CAN_DownloadDlg.h"
#include "Usbcan32.h"
#include "UcanIntf.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/*static tCanMsgStruct TxCanMsg_l =
{
    0x201,
    0,
    8,
    {0x01, 0x02, 0, 0, 0, 0, 0, 0},
    0
};*/

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnStnClickedAbtTxt1();
public:
	afx_msg void OnBnClickedOk();
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
	//ON_STN_CLICKED(IDC_ABT_TXT1, &CAboutDlg::OnStnClickedAbtTxt1)
	ON_STN_CLICKED(IDC_ABT_TXT1, &CAboutDlg::OnStnClickedAbtTxt1)
	ON_BN_CLICKED(IDOK, &CAboutDlg::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCAN_DownloadDlg dialog

CCAN_DownloadDlg::CCAN_DownloadDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCAN_DownloadDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCAN_DownloadDlg)
	m_sFileDisplay = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCAN_DownloadDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCAN_DownloadDlg)
	DDX_Control(pDX, IDC_FILEDISP, m_ctlFileDisplay);
	DDX_Control(pDX, IDC_PROGRESS, m_ctlProgress);
	DDX_Control(pDX, IDC_STATICDLPRG, m_ctlDownloading);
	DDX_Control(pDX, IDC_FILEDOWNLOAD, m_cFileDownload);
	DDX_Text(pDX, IDC_FILEDISP, m_sFileDisplay);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCAN_DownloadDlg, CDialog)
	//{{AFX_MSG_MAP(CCAN_DownloadDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_FILEOPEN, OnFileopen)
	ON_BN_CLICKED(IDC_FILEDOWNLOAD, OnFiledownload)
	ON_MESSAGE (WM_UCAN_RECEIVE, OnUcanReceive)						// Receive CAN message
	ON_MESSAGE (WM_UCAN_STATUS, OnUcanStatus)						// UCAN status
	ON_MESSAGE (WM_UCAN_FATAL_DISCONNECT, OnUcanFatalDisconnect)	// Error message for UCAN disconnect
	ON_BN_CLICKED(IDC_CANSETUP, OnCanSetup)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_ABOUT_BUTTON, &CCAN_DownloadDlg::OnBnClickedAboutButton)	//CSS
	ON_STN_CLICKED(DOWNLOAD_STATUS, &CCAN_DownloadDlg::OnStnClickedStatus)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCAN_DownloadDlg message handlers

BOOL CCAN_DownloadDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
    m_fInitOk      = FALSE;
    m_pUsbCanModul = NULL;
	m_dCANSetupDlg.m_sCANBitRate = "500";
	m_dCANSetupDlg.m_sCANMsgID = "200";
	m_dCANSetupDlg.m_iCANIDOption = 0;
	m_sLineCount = 0;
	m_iCANID = 0x200;
	m_iCANIDFormat = 0;
	m_iCANBitRate = USBCAN_BAUD_500kBit;
	m_lCANBitRate = USBCAN_BAUDEX_500kBit;
	m_bUnlock = FALSE;
	m_bDownloadEnable = FALSE;

	m_ctlDownloading.ShowWindow(FALSE);

    m_pUsbCanModul = new CUcanIntf (this);
    if (m_pUsbCanModul != NULL)
    {
        // initialiize USB-CANmodul
        m_fInitOk = m_pUsbCanModul->Initialize (USBCAN_ANY_MODULE, m_iCANBitRate, m_lCANBitRate);
    }

	if(!m_fInitOk)
		m_cFileDownload.EnableWindow(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCAN_DownloadDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCAN_DownloadDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCAN_DownloadDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CCAN_DownloadDlg::OnExit() 
{
	// TODO: Add your control notification handler code here
    if (m_fInitOk != FALSE)
    {
        m_pUsbCanModul->ShutDown ();
    }

	OnOK();
	
}

void CCAN_DownloadDlg::OnFileopen() 
{	
	//Clear status windows
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");
	GetDlgItem(DOWNLOAD_STATUS2)->SetWindowText("");
	
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("Select a MOT-file to download to target");	//CSS
	// TODO: Add your control notification handler code here
	CFileDialog m_ldFile(TRUE);

	m_ldFile.m_ofn.lpstrFilter = "Motorola S Record Format(*.mot)\0*.mot\0All Files (*.*)\0*.*";
	m_ldFile.m_ofn.lpstrInitialDir = ".\\";

	if(m_ldFile.DoModal() == IDOK)
	{
		CFile ldFile;
		CString buffer;

		ldFile.Open(m_ldFile.GetFileName(), CFile::modeRead);
		CArchive ar(&ldFile, CArchive::load);
		m_sFileDisplay = "";
		m_sLineCount = 0;
		while(ar.ReadString(buffer))
		{
			m_sFileDisplay += (buffer + "\r\n");
			m_sLineCount++;
		}
		m_ctlProgress.SetRange(0, m_sLineCount);
		UpdateData(FALSE);
	}
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");
}

void CCAN_DownloadDlg::OnFiledownload() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("Enter Device Unlock Code for target");	//CSS
	m_dUnlockDlg.m_sUnlockCode = "";
	if(m_dUnlockDlg.DoModal() == IDOK)
	{
		BOOL fRet;

		//Reset Status line 1
		status_line1_written = FALSE;
			
		m_pUsbCanModul->ShutDown ();
		m_fInitOk = m_pUsbCanModul->Initialize (USBCAN_ANY_MODULE, m_iCANBitRate, m_lCANBitRate);	//Already done.
		
		if (m_fInitOk != FALSE)
		{
			// write CAN message
			tCanMsgStruct tTxCANMsg;
			CString buffer, result;
			char *stopstring;
			int i, slength;

			buffer = m_dUnlockDlg.m_sUnlockCode;
			slength = buffer.GetLength();
			for(i = 16; i > slength; i--)
			{
				buffer = "0" + buffer;
			}

			for(i = 7; i >= 0; i--)
			{
				result = buffer.Right(2);
				buffer = buffer.Left(i * 2);
				tTxCANMsg.m_bData[i] = (unsigned char)strtol(result, &stopstring, 16);
			}

			m_bUnlock = FALSE;

			tTxCANMsg.m_dwID = m_iCANID + 1;
			tTxCANMsg.m_bFF = m_iCANIDFormat;
			tTxCANMsg.m_bDLC = 8;
			tTxCANMsg.m_dwTime = 0;

			fRet = m_pUsbCanModul->WriteMsg (&tTxCANMsg);	//Send CAN Device Unlock Code that user entered.
			if (fRet != FALSE)
			{
				m_ctlDownloading.ShowWindow(TRUE);	//CSS. Move to after erase success?
				m_bDownloadEnable = TRUE;
			}
			else
			{
			}
			
		}
//		m_sFileDisplay = m_dUnlockDlg.m_sUnlockCode;
//		UpdateData(FALSE);
	}
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");
}

void CCAN_DownloadDlg::OnCanSetup() 
{
	//Status windows
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("Set baudrate and FoCAN IDs. Must match target settings - not normally changed.");
	GetDlgItem(DOWNLOAD_STATUS2)->SetWindowText("");
		
	// TODO: Add your control notification handler code here
	if(m_dCANSetupDlg.DoModal() == IDOK)
	{
		char *stopstring;
		unsigned long sel;
		
		UpdateData(TRUE);

		m_iCANID = strtoul(m_dCANSetupDlg.m_sCANMsgID, &stopstring, 16);
		
		if(m_dCANSetupDlg.m_iCANIDOption == 0)
			m_iCANIDFormat = 0;
		else
			m_iCANIDFormat = 0x80;
		
		sel = strtoul(m_dCANSetupDlg.m_sCANBitRate, &stopstring, 10);
		switch(sel)
		{
		case 10:
			m_iCANBitRate = USBCAN_BAUD_10kBit;
			m_lCANBitRate = USBCAN_BAUDEX_10kBit;
			break;
		case 20:
			m_iCANBitRate = USBCAN_BAUD_20kBit;
			m_lCANBitRate = USBCAN_BAUDEX_20kBit;
			break;
		case 33:
			m_iCANBitRate = USBCAN_BAUD_33kBit;
			//m_lCANBitRate = USBCAN_BAUDEX_33kBit;
			break;
		case 50:
			m_iCANBitRate = USBCAN_BAUD_50kBit;
			m_lCANBitRate = USBCAN_BAUDEX_50kBit;
			break;
		case 83:
			m_iCANBitRate = USBCAN_BAUD_83kBit;
			//m_lCANBitRate = USBCAN_BAUDEX_83kBit;
			break;
		case 100:
			m_iCANBitRate = USBCAN_BAUD_100kBit;
			//m_lCANBitRate = USBCAN_BAUDEX_100kBit;
			break;
		case 125:
			m_iCANBitRate = USBCAN_BAUD_125kBit;
			m_lCANBitRate = USBCAN_BAUDEX_125kBit;
			break;
		case 250:
			m_iCANBitRate = USBCAN_BAUD_250kBit;
			m_lCANBitRate = USBCAN_BAUDEX_250kBit;
			break;
		case 500:
			m_iCANBitRate = USBCAN_BAUD_500kBit;
			m_lCANBitRate = USBCAN_BAUDEX_500kBit;
			break;
		case 1000:
			m_iCANBitRate = USBCAN_BAUD_1MBit;
			m_lCANBitRate = USBCAN_BAUDEX_1MBit;
			break;
		default:
			m_iCANBitRate = USBCAN_BAUD_500kBit;
			m_lCANBitRate = USBCAN_BAUDEX_500kBit;
			break;
		}
        
		m_pUsbCanModul->ShutDown ();
        m_fInitOk = FALSE;
		if (m_pUsbCanModul != NULL)
		{
			// initialiize USB-CANmodul
			m_fInitOk = m_pUsbCanModul->Initialize (USBCAN_ANY_MODULE, m_iCANBitRate, m_lCANBitRate);
		}
	}
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");
}

LRESULT CCAN_DownloadDlg::OnUcanStatus(WPARAM UcanHandle_p, LPARAM)
{
BOOL            fRet;
WORD            wStatus;

    if (m_fInitOk != FALSE)
    {
        // read CAN message
        fRet = m_pUsbCanModul->GetStatus (&wStatus);
        if (fRet != FALSE)
        {
            if ((wStatus & USBCAN_CANERR_XMTFULL)  != 0)
            {
                MessageBox("USB-CANmodul Tx-buffer of the CAN controller is full.", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (1, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_OVERRUN)  != 0)
            {
                MessageBox("USB-CANmodul Rx-buffer of the CAN controller is full.", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (2, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_BUSLIGHT) != 0)
            {
                MessageBox("USB-CANmodul Bus error: Error Limit 1 exceeded (refer to SJA1000 manual).", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (3, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_BUSHEAVY) != 0)
            {
                MessageBox("USB-CANmodul Bus error: Error Limit 2 exceeded (refer to SJA1000 manual).", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (4, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_BUSOFF)   != 0)
            {
                MessageBox("USB-CANmodul Bus error: CAN controller has gone into Bus-Off state.", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (5, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_QOVERRUN) != 0)
            {
                MessageBox("USB-CANmodul RcvQueue overrun.", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (6, SBPS_DISABLED);
            }

            if ((wStatus & USBCAN_CANERR_QXMTFULL) != 0)
            {
                MessageBox("USB-CANmodul transmit queue is full.", "CAN Error", MB_OK | MB_ICONERROR);
            }
            else
            {
//                m_wndStatusBar.SetPaneStyle (7, SBPS_DISABLED);
            }
        // initialiize USB-CANmodul
        m_fInitOk = m_pUsbCanModul->Initialize (USBCAN_ANY_MODULE, m_iCANBitRate, m_lCANBitRate);
        //m_pUsbCanModul->ShutDown();
        }
    }
	return 0;
}

LRESULT CCAN_DownloadDlg::OnUcanFatalDisconnect(WPARAM UcanHandle_p, LPARAM)
{
    if (m_pUsbCanModul->GetHandle () == (tUcanHandle) UcanHandle_p)
    {
        AfxMessageBox ("USB-CANmodul is disconnected!", MB_OK | MB_ICONERROR);
        //MessageBox("USB-CANmodul is disconnected!", "CAN Error", MB_OK | MB_ICONERROR);
        
        m_pUsbCanModul->ShutDown ();
        m_fInitOk = FALSE;
    }

    return 0;
}

//***************************************************************************
//
//	Receive from Systec Sniffer. This is called via UcanCallbackFkt() which 
//	was registered with the USBCAN-library by function UcanInitHardware().
//
//***************************************************************************
LRESULT CCAN_DownloadDlg::OnUcanReceive(WPARAM UcanHandle_p, LPARAM)
{
	BOOL            fRet = TRUE;
	tCanMsgStruct   RxCanMsg;
	int id;
	static int nr_other_msgs = 0;

    if (m_fInitOk != FALSE)
    {
        // Read CAN messages - until the buffer is empty!
		/* Found in Systec Control log file that the receive counter is always 3 when UcanReadCanMsg..() is called. 
		After receiving the callback event, you should call it in loop until this function returns the error code 
		USBCAN_WARN_NODATA. A better way to implement the read function is to use UcanReadCanMsgEx() which can read 
		more CAN messages than one. Below you find a little example:
		
		tUcanHandle UcanHandle;
		tCabMsgStruct RxCanMsg[16];
		UCANRET bRet;
		BYTE bChannel;
		DWORD dwCount;
		do //on callback event "receive"
		{
			// read up to 16 CAN-messages
			bChannel = USBCAN_CHANNEL_ANY;
			dwCount = sizeof (RxCanMsg) / sizeof (tCabMsgStruct);
			bRet = UcanReadCanMsgEx (UcanHandle, &bChannel, &RxCanMsg, &dwCount);
			if (USBCAN_CHECK_VALID_RXCANMSG (bRet))
			{
				PrintCanMessages (&RxCanMsg[0], dwCount);
				if (USBCAN_CHECK_WARNING (bRet))
				{
					PrintWarning (bRet);
				}
			}
			else if (USBCAN_CHECK_ERROR (bRet))
			{
				goto ErrorExit;
			}
		} */
		
		//while (fRet != FALSE)
		while (fRet != USBCAN_WARN_NODATA)
		{
			/* Get USB CAN sniffer CAN messages. */
			fRet = m_pUsbCanModul->ReadMsg (&RxCanMsg);
			
			//if (fRet != FALSE)
			if (fRet == USBCAN_SUCCESSFUL)
			{
				id = RxCanMsg.m_dwID - m_iCANID;
				switch(id)
				{
				case 1:
					//ACK from target. Target only sends control message IDs (X+1).
					if((m_bDownloadEnable == TRUE) && (RxCanMsg.m_bDLC == 1))
					{
						switch(RxCanMsg.m_bData[0])
						{
						case 0x55://Flash erase successful

							m_ctlDownloading.ShowWindow(TRUE);	//Added CSS
							if(m_bUnlock != TRUE)
							{
								m_bUnlock = TRUE;
							}
							m_iNextLine = 0;	//CSS previously inside if-statement
							m_iCurrLineBytesRemaining = 0;		//CSS "-
							TransferFile();		//CSS "-
							break;
						case 0xAA:
							TransferFile();
							break;
						case 0x22:
							TransferFile();
							break;
						default://Carl S: Add timeout so that this is also called at the end of a timeout.
								//This case will not occur anymore with a faulty Unlock Code, since 
								//"Unlock code check fail" has been removed from the latest FoCAN versions. 
								//This was removed in the device firmware to be able to flash in network,
								//and not have all the devices not being programmed to respond.
							m_bUnlock = FALSE;
							m_bDownloadEnable = FALSE;
							m_ctlDownloading.ShowWindow(FALSE);
							m_ctlProgress.SetPos(0);
							MessageBox("Download unsuccessful.", "Download Unsuccessful", MB_OK | MB_ICONERROR);
							break;
						}
					}
					break;
				default:
					//Just ignore.
					nr_other_msgs++;
					break;		
				}
			}
			else 
			/* One of 
			USBCAN_ERR_MAXINSTANCES 
			USBCAN_ERR_ILLHANDLE 
			USBCAN_ERR_CANNOTINIT 
			USBCAN_ERR_ILLPARAM 
			USBCAN_ERR_ILLHW 
			USBCAN_ERR_ILLCHANNEL 
			USBCAN_WARN_NODATA 
			USBCAN_WARN_SYS_RXOVERRUN 
			USBCAN_WARN_DLL_RXOVERRUN 
			USBCAN_WARN_FW_RXOVERRUN */
			{
				id = 0;	//Just testing, replace with something meaningful... CSS
			}
		}
    }

	return 0;
}

//***************************************************************************
//
//	Download file via Systec Sniffer
//
//***************************************************************************
BOOL CCAN_DownloadDlg::TransferFile()
{	
	if(m_bUnlock)
	{
		BOOL fRet;
		tCanMsgStruct tTxCANMsg;
		char *stopstring;
		int loop;
		
		m_ctlDownloading.ShowWindow(FALSE);	//CSS

		if (status_line1_written == FALSE)
		{
			m_sStatus.Format("SREC header address: ");	// CSS
			GetDlgItem(DOWNLOAD_STATUS)->SetWindowText(m_sStatus);	//CSS
			status_line1_written = TRUE;
		}

		/* If new line, send line header (address..) */
		if(m_iCurrLineBytesRemaining == 0)
		{
			*(short *)m_sLine = sizeof(m_sLine);	// First WORD of buffer must be size of the buffer
			if( m_ctlFileDisplay.GetLine(m_iNextLine, m_sLine) == 0x00)
			{
				MessageBox("m_ctlFileDisplay.GetLine() returned 'No characters'!");
			}

			if(m_sLine[0] == 'S')
			{
				//CString asdf;						// CSS debug
				//asdf.Format("m_sLineCount: %d\n m_iNextLine: %d\n m_sLine: %s",m_sLineCount, m_iNextLine, m_sLine);	// CSS
				//MessageBox(asdf);					// CSS debug
				//m_sStatus.Format("m_sLineCount: %d, m_iNextLine: %d", m_sLineCount, m_iNextLine);	// CSS
				//GetDlgItem(DOWNLOAD_STATUS)->SetWindowText(m_sStatus);	//CSS
				
				// First 3 bytes contain some code, e.g. S2 16 00, after that address.
				// Skip lines not beginning with S1-S3
				while(((m_sLine[1] < '1') || (m_sLine[1] > '3')) && (m_iNextLine < m_sLineCount))
				{
					m_iNextLine++;
					*(short *)m_sLine = sizeof(m_sLine);	// First WORD of buffer must be size of the buffer.
					m_ctlFileDisplay.GetLine(m_iNextLine, m_sLine);
				}

				m_ctlProgress.SetPos(m_iNextLine);

				if(m_iNextLine < m_sLineCount)
				{
					unsigned char sLineLength;
					CString cParseLine;	//CSS a string on stack used for parsing out parts of m_sLine.

					tTxCANMsg.m_dwID = m_iCANID + 1; // Build control frame
					tTxCANMsg.m_bFF = m_iCANIDFormat;
					tTxCANMsg.zm_dwTime = 0;
					
					/* Get nr bytes this line. */
					cParseLine = m_sLine[2];
					cParseLine += m_sLine[3];
					sLineLength = (unsigned char)strtoul(cParseLine, &stopstring, 16);

					switch (m_sLine[1])
					{
					// S1... = ?
					case '1':
						m_sStatus.Format("");	// CSS
						/* Get address */
						for(loop = 0; loop < 2; loop++)
						{
							/* Get two string characters at a time and convert to a hex byte, and put 
							in CAN data field (flash data!) */
							cParseLine = m_sLine[loop * 2 + 4];
							cParseLine += m_sLine[loop * 2 + 5];
							tTxCANMsg.m_bData[loop + 1] = (unsigned char)strtoul(cParseLine, &stopstring, 16);
							/* Address string for output to user. */
							m_sStatus += cParseLine;
						}
						cParseLine = m_sLine[sLineLength * 2 + 2];
						cParseLine += m_sLine[sLineLength * 2 + 3];
						tTxCANMsg.m_bData[3] = (unsigned char)strtoul(cParseLine, &stopstring, 16);

						tTxCANMsg.m_bDLC = 4;
						tTxCANMsg.m_bData[0] = sLineLength - 3;
						m_iCurrLineBytesRemaining = sLineLength - 3;
						m_iDataOffset = 4;
						break;
					// S2... = a line containing code to send?	Code address begins with m_sLine[5]
					//											Code data begins with m_sLine[10]? (R8C)
					case '2':
						m_sStatus.Format("");	// CSS
						/* Get address */
						for(loop = 0; loop < 3; loop++)
						{
							cParseLine = m_sLine[loop * 2 + 4]; //m_sLine[4], [6], [8]
							cParseLine += m_sLine[loop * 2 + 5];//m_sLine[5], [7], [9]
							tTxCANMsg.m_bData[loop + 1] = (unsigned char)strtoul(cParseLine, &stopstring, 16);
							/* Address string for output to user. */
							m_sStatus += cParseLine;
						}
						cParseLine = m_sLine[sLineLength * 2 + 2];
						cParseLine += m_sLine[sLineLength * 2 + 3];
						tTxCANMsg.m_bData[4] = (unsigned char)strtoul(cParseLine, &stopstring, 16);

						tTxCANMsg.m_bDLC = 5;
						tTxCANMsg.m_bData[0] = sLineLength - 4; //Control frame, data length
						m_iCurrLineBytesRemaining = sLineLength - 4;
						m_iDataOffset = 5;						
						break;
					// S3... = ?
					case '3':
						m_sStatus.Format("");	// CSS
						/* Get address */
						for(loop = 0; loop < 4; loop++)
						{
							cParseLine = m_sLine[loop * 2 + 4];
							cParseLine += m_sLine[loop * 2 + 5];
							tTxCANMsg.m_bData[loop + 1] = (unsigned char)strtoul(cParseLine, &stopstring, 16);
							/* Address string for output to user. */
							m_sStatus += cParseLine;
						}
						cParseLine = m_sLine[sLineLength * 2 + 2];
						cParseLine += m_sLine[sLineLength * 2 + 3];
						tTxCANMsg.m_bData[5] = (unsigned char)strtoul(cParseLine, &stopstring, 16);

						tTxCANMsg.m_bDLC = 6;
						tTxCANMsg.m_bData[0] = sLineLength - 5;
						m_iCurrLineBytesRemaining = sLineLength - 5;
						m_iDataOffset = 6;
						break;
					}

					default:
						/* Error? Only S1-S3 possible? */
						break;
					
					/* Show user the address */
					GetDlgItem(DOWNLOAD_STATUS2)->SetWindowText(m_sStatus);	//CSS

					fRet = m_pUsbCanModul->WriteMsg (&tTxCANMsg);	//@@ Send Address data
					if (fRet != FALSE)
					{
						m_iNextLine++;
					}
					else
					{
						MessageBox("USB CANmodul Write Msg error");
					}

				}
				else  // End of file
				{
					//MessageBox("EOF");//CSS debug
					m_bUnlock = FALSE;
					m_bDownloadEnable = FALSE;
					m_ctlProgress.SetPos(0);

					tTxCANMsg.m_dwID = m_iCANID + 1;
					tTxCANMsg.m_bFF = m_iCANIDFormat;
					tTxCANMsg.m_bDLC = 1; //= RESET_DLC
					GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");	//CSS
					GetDlgItem(DOWNLOAD_STATUS2)->SetWindowText("End Of File, Sending Reset DLC.");	//CSS
					tTxCANMsg.m_bData[0] = 0x5a;
					tTxCANMsg.m_dwTime = 0;

					fRet = m_pUsbCanModul->WriteMsg (&tTxCANMsg);
					if (fRet != FALSE)
					{
						//m_pUsbCanModul->Reset();	Will need to initialize again aswell if this is used.
					}
					else
					{
					}
				}
			}
			else
			{
				MessageBox("Unknown file format.","Unknown file format", MB_OK | MB_ICONERROR);
				GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("Unknown file format");
				m_bUnlock = FALSE;
				m_bDownloadEnable = FALSE;
				m_ctlProgress.SetPos(0);
			}
		}
		else // Not new line	CSS: Send data
		{
			tTxCANMsg.m_dwID = m_iCANID;
			tTxCANMsg.m_bFF = m_iCANIDFormat;
			tTxCANMsg.m_dwTime = 0;

			int loopcount;

			if(m_iCurrLineBytesRemaining >= 8)
			{
				loopcount = 8;
				m_iCurrLineBytesRemaining -= 8;
			}
			else
			{
				loopcount = m_iCurrLineBytesRemaining;
				m_iCurrLineBytesRemaining = 0;
			}
						
			tTxCANMsg.m_bDLC = loopcount;

			for(loop = 0; loop < loopcount; loop++)
			{
				cParseLine = m_sLine[(m_iDataOffset + loop) * 2];
				cParseLine += m_sLine[(m_iDataOffset + loop) * 2 + 1];
				tTxCANMsg.m_bData[loop] = (unsigned char)strtoul(cParseLine, &stopstring, 16);
			}

			fRet = m_pUsbCanModul->WriteMsg (&tTxCANMsg);	//@@ Write flash data
			if (fRet != FALSE)
			{
			}
			else
			{
			}
			//CSS: Increment data offset in current S-rec line.
			m_iDataOffset += loopcount;
		}

	}
	return TRUE;
}


void CCAN_DownloadDlg::OnBnClickedAboutButton()
{
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("About FoCAN-Download!");
	GetDlgItem(DOWNLOAD_STATUS2)->SetWindowText("");
	
	// TODO: Add your control notification handler code here
	CAboutDlg	m_about_dlg;
	m_about_dlg.DoModal();
	GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("");
}



void CCAN_DownloadDlg::OnStnClickedStatus()
{
	// TODO: Add your control notification handler code here
}

void CAboutDlg::OnStnClickedAbtTxt1()
{
	// TODO: Add your control notification handler code here
}

void CAboutDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	OnOK();
}

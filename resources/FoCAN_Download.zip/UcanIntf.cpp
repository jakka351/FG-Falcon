// UcanIntf.cpp: Implementierung der Klasse CUcanIntf.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "UcanIntf.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


/***************************************************************************/
/*                                                                         */
/*                                                                         */
/*          G L O B A L   D E F I N I T I O N S                            */
/*                                                                         */
/*                                                                         */
/***************************************************************************/

//---------------------------------------------------------------------------
// const defines
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// modul global types
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
// modul global vars
//---------------------------------------------------------------------------

static CWnd* pEventWnd_l          = NULL;
static DWORD dwPlugAndPlayCount_l = 0;


//=========================================================================//
//                                                                         //
//          P U B L I C   F U N C T I O N S                                //
//                                                                         //
//=========================================================================//

//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::CUcanIntf()
//
// Description: constructor
//
// Parameters:  pWnd_p
//
// Return:      
//
// State:       
//
//---------------------------------------------------------------------------

CUcanIntf::CUcanIntf(CWnd* pWnd_p)
{

    m_fIsInitialized = FALSE;
    m_UcanHandle     = USBCAN_INVALID_HANDLE;

    // only one window should use this class
    ASSERT (pWnd_p != NULL);
    ASSERT ((pEventWnd_l == NULL) || (pEventWnd_l == pWnd_p));
    pEventWnd_l = pWnd_p;

    if (dwPlugAndPlayCount_l == 0)
    {
        // initialize callback handler for plug & play events
        // NOTE:
        // Call this function before UcanInitHardware() - so you can also receive
        // the plug & play event FATAL_DISCONNECT.
        ::UcanInitHwConnectControl (UcanConnectControlFkt);
    }
    dwPlugAndPlayCount_l++;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::~CUcanIntf()
//
// Description: destructor
//
// Parameters:  
//
// Return:      
//
// State:       
//
//---------------------------------------------------------------------------

CUcanIntf::~CUcanIntf()
{

    // disable plug & play callback handler if the las instance is deleted
    dwPlugAndPlayCount_l--;
    if (dwPlugAndPlayCount_l == 0)
    {
        // deinitialize callback handler
        ::UcanDeinitHwConnectControl ();
    }

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::Initialize()
//
// Description: initializes a USB-CANmodul
//
// Parameters:  bDeviceNr_p
//              wBTR_p
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::Initialize (BYTE bDeviceNr_p, WORD wBTR_p, LONG m_lCANBitRate)
{
BYTE                bRet              = USBCAN_SUCCESSFUL;
BOOL                fRet              = m_fIsInitialized;
BOOL                fHwIsInitialized  = m_fIsInitialized;
BOOL                fCanIsInitialized = m_fIsInitialized;
tUcanInitCanParam   InitParam;

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized == FALSE)
    {
        // initialize hardware
        bRet = ::UcanInitHardware (&m_UcanHandle, bDeviceNr_p, UcanCallbackFkt);
        if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }

        // fill out initialisation struct
        InitParam.m_dwSize  = sizeof (InitParam);           // size of this struct
        InitParam.m_bMode   = kUcanModeNormal;              // normal operation mode
        InitParam.m_bBTR0   = HIBYTE (wBTR_p);              // baudrate
        InitParam.m_bBTR1   = LOBYTE (wBTR_p);
        InitParam.m_bOCR    = 0x1A;                         // standard output
        InitParam.m_dwAMR   = USBCAN_AMR_ALL;               // receive all CAN messages
        InitParam.m_dwACR   = USBCAN_ACR_ALL;
		InitParam.m_dwBaudrate = m_lCANBitRate;				// Added for 3204000 analyzer

        // initialize CAN interface
		bRet = ::UcanInitCan (m_UcanHandle, InitParam.m_bBTR0, InitParam.m_bBTR1, InitParam.m_dwAMR, InitParam.m_dwACR);
        //bRet = ::UcanInitCanEx (m_UcanHandle, &InitParam);

		if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }

        // initialisation complete
        m_fIsInitialized = TRUE;
        fRet = TRUE;
    }

Exit:
    // error?
    if (bRet != USBCAN_SUCCESSFUL)
    {
        if (fCanIsInitialized != FALSE)
        {
            // deinitialize CAN interface
            ::UcanDeinitCan (m_UcanHandle);
        }

        if (fHwIsInitialized != FALSE)
        {
            // deinitialize hardware
            ::UcanDeinitHardware (m_UcanHandle);
        }
    }

    return fRet;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::ShutDown()
//
// Description: deinitializes a USB-CANmodul
//
// Parameters:  
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::ShutDown()
{

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        // deinitialize CAN interface
        ::UcanDeinitCan (m_UcanHandle);

        // deinitialize hardware
        ::UcanDeinitHardware (m_UcanHandle);

        m_fIsInitialized = FALSE;
        m_UcanHandle     = USBCAN_INVALID_HANDLE;
    }

    return TRUE;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::ReadMsg()
//
// Description: reads a CAN message from USB-CANmodul
//
// Parameters:  *pCanMsg_p
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::ReadMsg (tCanMsgStruct *pCanMsg_p)
{

BOOL    fRet    = m_fIsInitialized;
BYTE    bRet;

    ASSERT (pCanMsg_p != NULL);

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        fRet = FALSE;

        // read CAN message
        //bRet = ::UcanReadCanMsg (m_UcanHandle, pCanMsg_p);
		/* Can't stand this return mechanism. Give me the actual value!!! */
		return ::UcanReadCanMsg (m_UcanHandle, pCanMsg_p);
		/*
		if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }
        fRet = TRUE;
		*/
    }
/*
Exit:
    return fRet;
*/
}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::WriteMsg()
//
// Description: writes a CAN message to USB-CANmodul
//
// Parameters:  *pCanMsg_p
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::WriteMsg (tCanMsgStruct *pCanMsg_p)
{

BOOL    fRet    = m_fIsInitialized;
BYTE    bRet;

    ASSERT (pCanMsg_p != NULL);

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        fRet = FALSE;

        // write CAN message
        bRet = ::UcanWriteCanMsg (m_UcanHandle, pCanMsg_p);
        if (bRet != USBCAN_SUCCESSFUL)
        {
		    return fRet;
        }
        else
			fRet = TRUE;
    }
	return fRet;
}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::GetHwInfo()
//
// Description: reads the hardware information struct
//
// Parameters:  *pUcanHwInfo_p
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::GetHwInfo(tUcanHardwareInfo *pUcanHwInfo_p)
{

BOOL    fRet    = m_fIsInitialized;
BYTE    bRet;

    ASSERT (pUcanHwInfo_p != NULL);

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        fRet = FALSE;

        // write CAN message
        bRet = ::UcanGetHardwareInfo (m_UcanHandle, pUcanHwInfo_p);
        if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }

        fRet = TRUE;
    }

Exit:
    return fRet;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::Reset()
//
// Description: resets CAn onterface of USB-CANmodul
//
// Parameters:  
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::Reset()
{

BOOL    fRet    = m_fIsInitialized;
BYTE    bRet;

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        fRet = FALSE;

        // reset CAN interface
        bRet = ::UcanResetCan (m_UcanHandle);
        if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }

        fRet = TRUE;
    }

Exit:
    return fRet;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::GetStatus()
//
// Description: 
//
// Parameters:  *pwStatus_p
//
// Return:      BOOL
//
// State:       
//
//---------------------------------------------------------------------------

BOOL CUcanIntf::GetStatus(WORD *pwStatus_p)
{

BOOL            fRet    = m_fIsInitialized;
BYTE            bRet;
tStatusStruct   Status;

    ASSERT (pwStatus_p != NULL);

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        fRet = FALSE;

        // reset CAN interface
        bRet = ::UcanGetStatus (m_UcanHandle, &Status);
        if (bRet != USBCAN_SUCCESSFUL)
        {
            goto Exit;
        }

        *pwStatus_p = Status.m_wCanStatus;
        fRet = TRUE;
    }

Exit:
    return fRet;

}


//---------------------------------------------------------------------------
//
// Function:    CUcanIntf::GetHandle()
//
// Description: returnes the handle to the USB-CANmodul
//
// Parameters:  
//
// Return:      tUcanHandle
//
// State:       
//
//---------------------------------------------------------------------------

tUcanHandle CUcanIntf::GetHandle ()
{

tUcanHandle UcanHandle = USBCAN_INVALID_HANDLE;

    // check if USB-CANmodul already is initialized
    if (m_fIsInitialized != FALSE)
    {
        UcanHandle = m_UcanHandle;
    }

    return UcanHandle;

}


//---------------------------------------------------------------------------
//
// Function:    UcanCallbackFkt()
//
// Description: callback function to receive events from USB-CANmodul
//              (working events)
//
// Parameters:  UcanHandle_p
//              bEvent_p
//
// Return:      void
//
// State:       
//
//---------------------------------------------------------------------------

void PUBLIC UcanCallbackFkt (tUcanHandle UcanHandle_p, BYTE bEvent_p)
{
    //----------------------------------------------------------------------------
    // NOTE:
    // Do not call functions of USBCAN32.DLL directly from this callback handler.
    // Use events or windows messages to notify the event to the application.
    //----------------------------------------------------------------------------

    // check event
    switch (bEvent_p)
    {
        // hardware initialized
        case USBCAN_EVENT_INITHW:
            break;

        // CAN interface initialized
        case USBCAN_EVENT_INITCAN:
            break;

        // CAN message received
        case USBCAN_EVENT_RECIEVE:
            pEventWnd_l->PostMessage (WM_UCAN_RECEIVE, (WPARAM) UcanHandle_p, 0);
            break;

        // status message received
        case USBCAN_EVENT_STATUS:
            pEventWnd_l->PostMessage (WM_UCAN_STATUS, (WPARAM) UcanHandle_p, 0);
            break;

        // CAN interface deinitialized
        case USBCAN_EVENT_DEINITCAN:
            break;

        // hardware deinitialized
        case USBCAN_EVENT_DEINITHW:
            break;

        // unknown event
        default:
            break;
    }

}


//---------------------------------------------------------------------------
//
// Function:    UcanConnectControlFkt()
//
// Description: callback function to receive events from USB-CANmodul
//              (plug & play events)
//
// Parameters:  bEvent_p
//              dwParam_p
//
// Return:      void
//
// State:       
//
//---------------------------------------------------------------------------

void PUBLIC UcanConnectControlFkt (BYTE bEvent_p, DWORD dwParam_p)
{

    //----------------------------------------------------------------------------
    // NOTE:
    // Do not call functions of USBCAN32.DLL directly from this callback handler.
    // Use events or windows messages to notify the event to the application.
    //----------------------------------------------------------------------------

    // check event
    switch (bEvent_p)
    {
        // new USB-CANmodul connected
        case USBCAN_EVENT_CONNECT:

            pEventWnd_l->PostMessage (WM_UCAN_CONNECT, (WPARAM) dwParam_p, 0);
            break;

        // an other USB-CANmodul disconnected
        case USBCAN_EVENT_DISCONNECT:

            pEventWnd_l->PostMessage (WM_UCAN_DISCONNECT, (WPARAM) dwParam_p, 0);
            break;

        // an used USB-CANmodul disconnected
        case USBCAN_EVENT_FATALDISCON:

            pEventWnd_l->PostMessage (WM_UCAN_FATAL_DISCONNECT, (WPARAM) dwParam_p, 0);
            break;

        // unknown event
        default:
            break;
    }

}

// CANSetupDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CAN_Download.h"
#include "CANSetupDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCANSetupDlg dialog


CCANSetupDlg::CCANSetupDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCANSetupDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCANSetupDlg)
	m_sCANBitRate = _T("");
	m_sCANMsgID = _T("");
	m_iCANIDOption = -1;
	//}}AFX_DATA_INIT
}


void CCANSetupDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCANSetupDlg)
	DDX_CBString(pDX, IDC_CANBITRATE, m_sCANBitRate);
	DDX_Text(pDX, IDC_CANMSGID, m_sCANMsgID);
	DDV_MaxChars(pDX, m_sCANMsgID, 8);
	DDX_Radio(pDX, IDC_RSTDID, m_iCANIDOption);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCANSetupDlg, CDialog)
	//{{AFX_MSG_MAP(CCANSetupDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCANSetupDlg message handlers


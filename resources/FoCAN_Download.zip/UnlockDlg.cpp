// UnlockDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CAN_Download.h"
#include "UnlockDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUnlockDlg dialog


CUnlockDlg::CUnlockDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUnlockDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUnlockDlg)
	m_sUnlockCode = _T("");
	//}}AFX_DATA_INIT
}


void CUnlockDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUnlockDlg)
	DDX_Control(pDX, IDC_UNLOCKCODE, m_ctlUnlockCode);
	DDX_Text(pDX, IDC_UNLOCKCODE, m_sUnlockCode);
	DDV_MaxChars(pDX, m_sUnlockCode, 16);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUnlockDlg, CDialog)
	//{{AFX_MSG_MAP(CUnlockDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CUnlockDlg::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUnlockDlg message handlers

BOOL CUnlockDlg::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CDialog::Create(IDD, pParentWnd);
}

void CUnlockDlg::OnBnClickedOk()
{
		//GetDlgItem(DOWNLOAD_STATUS)->SetWindowText("If Device Unlock Code exists: Erase, then download.");		//CSS
		OnOK();
}

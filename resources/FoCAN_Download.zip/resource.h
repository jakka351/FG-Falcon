//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CAN_Download.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CAN_DOWNLOAD_DIALOG         102
#define IDD_TEST_DIALOG                 103
#define IDR_MAINFRAME                   128
#define IDD_UNLOCKDLG                   129
#define IDD_CANSETUPDLG                 130
#define IDD_DIALOGBAR                   131
#define IDB_BITMAP1                     133
#define IDB_BITMAP2                     136
#define IDC_FILEDISP                    1000
#define IDC_FILEOPEN                    1001
#define IDC_FILEDOWNLOAD                1002
#define IDC_CANSETUP                    1003
#define IDC_EXIT                        1004
#define IDC_UNLOCKCODE                  1005
#define IDC_CANBITRATE                  1007
#define IDC_CANMSGID                    1008
#define IDC_RSTDID                      1009
#define IDC_REXTID                      1010
#define IDC_STATICDLPRG                 1013
#define IDC_PROGRESS                    1014
#define DOWNLOAD_STATUS                 1015
#define IDC_LABEL1                      1016
#define DOWNLOAD_STATUS2                1016
#define IDC_IVICOLORXCTRL1              1017
#define IDC_ABOUT_PIC                   1017
#define IDC_ABOUT_BUTTON                1018
#define IDC_LOGO                        1020
#define IDC_ABT_TXT1                    1021
#define IDC_ABT_TXT2                    1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif

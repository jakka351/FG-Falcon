#if !defined(AFX_CANSETUPDLG_H__57E4577B_A420_4E6B_AAEF_275A306A228C__INCLUDED_)
#define AFX_CANSETUPDLG_H__57E4577B_A420_4E6B_AAEF_275A306A228C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CANSetupDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCANSetupDlg dialog

class CCANSetupDlg : public CDialog
{
// Construction
public:
	CCANSetupDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCANSetupDlg)
	enum { IDD = IDD_CANSETUPDLG };
	CString	m_sCANBitRate;
	CString	m_sCANMsgID;
	int		m_iCANIDOption;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCANSetupDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCANSetupDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CANSETUPDLG_H__57E4577B_A420_4E6B_AAEF_275A306A228C__INCLUDED_)

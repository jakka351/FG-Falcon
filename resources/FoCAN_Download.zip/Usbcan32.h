/****************************************************************************

  (c) SYSTEC electronic GmbH, D-07973 Greiz, August-Bebel-Str. 29
      www.systec-electronic.de

  Project:      USB-CANmodule

  Description:  Standard header file for the USBCAN32.DLL

  -------------------------------------------------------------------------

                $RCSfile:$

                $Author: R.Dietzsch $

                $Revision: 1.1 $  $Date: 2003/03/18 $
                Version: 2.18  Date: 27.04.2004

                $State: $

                Build Environment:
                    MSVC 5.0 and MSVC 6.0

  -------------------------------------------------------------------------

  Revision History:

  2003/03/17 r.d.:  Parameter m_dwSerialNr in tUcanHardwareInfo included.
  2003/03/18 r.d.:  New Function UcanInitCanEx() for additional init parameters.
                    UcanGetVersion() returns standard version format.
  2005/10/12 r.d.:  Several new functions included for USB-CANmodul GW-006 or
                    Multiport 3004006

****************************************************************************/


// Protection against mutliple including
#ifndef __USBCAN32_H__
#define __USBCAN32_H__


// allow access to functions for C++ applications as well
#ifdef __cplusplus
extern "C"
{
#endif

#ifdef WIN32

    // obsolate define
    #ifndef STDCALL
    #define STDCALL __stdcall
    #endif

    // new define
    #ifndef PUBLIC
    #define PUBLIC __stdcall
    #endif

#else

    // obsolate define
    #ifndef STDCALL
    #define STDCALL far pascal
    #endif

    // new define
    #ifndef PUBLIC
    #define PUBLIC far pascal
    #endif

#endif


//---------------------------------------------------------------------------
// macro definition
//---------------------------------------------------------------------------

// Filter calculation:

// Extended Frame:
// 33222222 22221111 11111100 00000000 \ (Bits 0-31 of AMR and ACR)
// 10987654 32109876 54321098 76543210 /
// -------- -------- -------- -----    > 29-Bit ID
//                                 -   > RTR-Bit        > GW-002 only
//                                 .-- > unused

// Standard Frame:
// 33222222 22221111 11111100 00000000 \ (Bits 0-31 of AMR and ACR)
// 10987654 32109876 54321098 76543210 /
// -------- ---                        > 11-Bit ID
//             -                       > RTR-Bit        > GW-002 only
//             .---- ........ ........ > unused
//                   --------          > Data byte 0    \ GW-002 only
//                            -------- > Data byte 1    /

// Macros for calculation of vallues for acceptance filter
#define USBCAN_SET_AMR(extended, can_id, rtr) \
    (extended) ?    ((((DWORD)can_id)<<3 )|((rtr)?0x000004:0)|0x00003) : \
                    ((((DWORD)can_id)<<21)|((rtr)?0x100000:0)|0xfffff)
#define USBCAN_SET_ACR(extended, can_id, rtr) \
    (extended) ?    ((((DWORD)can_id)<<3 )|((rtr)?0x000004:0)) : \
                    ((((DWORD)can_id)<<21)|((rtr)?0x100000:0))


//---------------------------------------------------------------------------
//
// Function:    USBCAN_CALCULATE_AMR() USBCAN_CALCULATE_ACR()
//
// Description: macros are calculating AMR and ACR using CAN-ID as parameter
//
//              NOTE:   This macros only are working if both from-id and
//                      to-id results a successive order of bits.
//              Example:
//                      from-id: 0x000  to-id:  0x01F   --> macros are working
//                      from-id: 0x400  to-id:  0x4FF   --> macros are working
//                      from-id: 0x101  to-id:  0x202   --> macros are NOT working
//
// A received CAN messages (with CAN-ID = RxID) will be accepted if the following
// condition is fulfilled:
//      ((~(RxID ^ ACR) | AMR) == 0xFFFFFFFF)
//
// Parameters:  extended    = [IN] if TRUE parameters from_id and to_id contains 29-bit CAN-ID
//              from_id     = [IN] first CAN-ID which should be received
//              to_id       = [IN] last CAN-ID which should be received
//              rtr_only    = [IN] if TRUE only RTR-Messages should be received, and rtr_too will be ignored
//              rtr_too     = [IN] if TRUE CAN data frames and RTR-Messages should be received
//
//              NOTE: Parameters rtr_only and rtr_too will be ignored for GW-006 or Multiport 3004006.
//
// Return:      DWORD       = AMR or ACR
//
//---------------------------------------------------------------------------

#define USBCAN_CALCULATE_AMR(extended,from_id,to_id,rtr_only,rtr_too) \
    (extended) ?    ((((DWORD)(from_id)^(to_id))<<3 )|((rtr_too&!rtr_only)?0x000004:0)|0x00003) : \
                    ((((DWORD)(from_id)^(to_id))<<21)|((rtr_too&!rtr_only)?0x100000:0)|0xfffff)
#define USBCAN_CALCULATE_ACR(extended,from_id,to_id,rtr_only,rtr_too) \
    (extended) ?    ((((DWORD)(from_id)&(to_id))<<3 )|((rtr_only)?0x000004:0)) : \
                    ((((DWORD)(from_id)&(to_id))<<21)|((rtr_only)?0x100000:0))

// macros to vonvert version iformations from functions UcanGetVersionEx() and UcanGetFwVersion()
#define USBCAN_MAJOR_VER(ver)       ( (ver) & 0x000000FF)
#define USBCAN_MINOR_VER(ver)       (((ver) & 0x0000FF00) >> 8)
#define USBCAN_RELEASE_VER(ver)     (((ver) & 0xFFFF0000) >> 16)


//---------------------------------------------------------------------------
// const defines
//---------------------------------------------------------------------------

// maximum number of modules, that are supported (can not be changed!)
#define USBCAN_MAX_MODULES              64

// maximum number of applications, that can make use of this DLL (can not be changed!)
#define USBCAN_MAX_INSTANCES            64

// With the function UcanInitHardware() the module is used, which is detected first.
// This define should only be used, in case only one module is connected to the computer.
#define USBCAN_ANY_MODULE               255

// no valid USB-CAN Handle
#define USBCAN_INVALID_HANDLE           0xff

// pre-defined baudrate values for GW-001 and GW-002 (use function UcanInitCan or UcanSetBaudrate)
#define USBCAN_BAUD_1MBit               0x0014              // = 1000 kBit/s
#define USBCAN_BAUD_800kBit             0x0016              // =  800 kBit/s
#define USBCAN_BAUD_500kBit             0x001c              // =  500 kBit/s
#define USBCAN_BAUD_250kBit             0x011c              // =  250 kBit/s
#define USBCAN_BAUD_125kBit             0x031c              // =  125 kBit/s
#define USBCAN_BAUD_100kBit             0x432f              // =  100 kBit/s
#define USBCAN_BAUD_83kBit              0x451c              // =   83.3 kBit/s
#define USBCAN_BAUD_50kBit              0x472f              // =   50 kBit/s
#define USBCAN_BAUD_33kBit              0x4b2f              // =   33.3 kBit/s
#define USBCAN_BAUD_20kBit              0x532f              // =   20 kBit/s
#define USBCAN_BAUD_10kBit              0x672f              // =   10 kBit/s

#define USBCAN_BAUD_USE_BTREX           0x0000              // uses predefined extended values of baudrate for
                                                            // GW-006 or Multiport 3004006 (do not use for GW-001/002)
#define USBCAN_BAUD_AUTO                0xFFFF              // automatic baudrate detection (not implemented in this version)

// pre-defined baudrate values for GW-006 or Multiport 3004006 (use function UcanInitCanEx or UcanSetBaudrateEx)
#define USBCAN_BAUDEX_1MBit             0x00020354          // = 1000 kBit/s
#define USBCAN_BAUDEX_800kBit           0x00030254          // =  800 kBit/s
#define USBCAN_BAUDEX_500kBit           0x00050354          // =  500 kBit/s
#define USBCAN_BAUDEX_250kBit           0x000B0354          // =  250 kBit/s
#define USBCAN_BAUDEX_125kBit           0x00170354          // =  125 kBit/s
#define USBCAN_BAUDEX_100kBit           0x00170466          // =  100 kBit/s
#define USBCAN_BAUDEX_50kBit            0x002F0466          // =   50 kBit/s
#define USBCAN_BAUDEX_20kBit            0x00770466          // =   20 kBit/s
#define USBCAN_BAUDEX_10kBit            0x80770466          // =   10 kBit/s (CLK = 1, see L-487 since version 15)

#define USBCAN_BAUDEX_USE_BTR01         0x00000000          // uses predefined values of BTR0/BTR1 for GW-001/002
#define USBCAN_BAUDEX_AUTO              0xFFFFFFFF          // automatic baudrate detection (not implemented in this version)

// Frame format for a CAN message (bit oriented)
#define USBCAN_MSG_FF_STD               0x00                // Standard Frame (11-Bit-ID)
#define USBCAN_MSG_FF_ECHO              0x20                // Tx echo (message received from UcanReadCanMsg.. was previously sent by UcanWriteCanMsg..)
#define USBCAN_MSG_FF_RTR               0x40                // Remote Transmition Request Frame
#define USBCAN_MSG_FF_EXT               0x80                // Extended Frame (29-Bit-ID)

// Function return codes (encoding)
#define USBCAN_SUCCESSFUL               0x00                // no error
#define USBCAN_ERR                      0x01                // error in DLL; function has not been executed
#define USBCAN_ERRCMD                   0x40                // error in module; function has not been executed
#define USBCAN_WARNING                  0x80                // Warning; function has been executed anyway
#define USBCAN_RESERVED                 0xc0                // reserved return codes (up to 255)

// Error messages, that can occur in the DLL
#define USBCAN_ERR_RESOURCE             0x01                // could not created a resource (memory, Handle, ...)
#define USBCAN_ERR_MAXMODULES           0x02                // the maximum number of open modules is exceeded
#define USBCAN_ERR_HWINUSE              0x03                // a module is already in use
#define USBCAN_ERR_ILLVERSION           0x04                // the software versions of the module and DLL are incompatible
#define USBCAN_ERR_ILLHW                0x05                // the module with the corresponding device number is not connected
#define USBCAN_ERR_ILLHANDLE            0x06                // wrong USB-CAN-Handle handed over to the function
#define USBCAN_ERR_ILLPARAM             0x07                // wrong parameter handed over to the function
#define USBCAN_ERR_BUSY                 0x08                // instruction can not be processed at this time
#define USBCAN_ERR_TIMEOUT              0x09                // no answer from the module
#define USBCAN_ERR_IOFAILED             0x0a                // a request for the driver failed
#define USBCAN_ERR_DLL_TXFULL           0x0b                // the message did not fit into the transmission queue
#define USBCAN_ERR_MAXINSTANCES         0x0c                // maximum number of applications is reached
#define USBCAN_ERR_CANNOTINIT           0x0d                // CAN-interface is not yet initialized
#define USBCAN_ERR_DISCONECT            0x0e                // USB-CANmodul was disconnected
#define USBCAN_ERR_NOHWCLASS            0x0f                // the needed device class does not exist
#define USBCAN_ERR_ILLCHANNEL           0x10                // illegal CAN channel for GW-001/GW-002

// Error messages, that the module returns during the command sequence
#define USBCAN_ERRCMD_NOTEQU            0x40                // the received response does not match with the transmitted command
#define USBCAN_ERRCMD_REGTST            0x41                // no access to the CAN controler possible
#define USBCAN_ERRCMD_ILLCMD            0x42                // the module could not interpret the command
#define USBCAN_ERRCMD_EEPROM            0x43                // error while reading the EEPROM occured
#define USBCAN_ERRCMD_RESERVED1         0x44
#define USBCAN_ERRCMD_RESERVED2         0x45
#define USBCAN_ERRCMD_RESERVED3         0x46
#define USBCAN_ERRCMD_ILLBDR            0x47                // illegal baudrate values for GW-006 or Multiport 3004006 in BTR0/BTR1
#define USBCAN_ERRCMD_NOTINIT           0x48                // CAN channel was not initialized
#define USBCAN_ERRCMD_ALREADYINIT       0x49                // CAN channel was already initialized

// Warning messages, that can occur in the DLL
// NOTE: These messages are only warnings. The function has been executed anyway.
#define USBCAN_WARN_NODATA              0x80                // no CAN messages received
#define USBCAN_WARN_SYS_RXOVERRUN       0x81                // overrun in the receive queue of the driver (but this CAN message is successfuly read)
#define USBCAN_WARN_DLL_RXOVERRUN       0x82                // overrun in the receive queue of the DLL (but this CAN message is successfuly read)
#define USBCAN_WARN_RESERVED1           0x83
#define USBCAN_WARN_RESERVED2           0x84
#define USBCAN_WARN_FW_TXOVERRUN        0x85                // overrun in the transmit queue of the firmware (but this message was successfuly stored in buffer)
#define USBCAN_WARN_FW_RXOVERRUN        0x86                // overrun in the receive queue of the firmware (but this CAN message is successfuly read)
#define USBCAN_WARN_NULL_PTR            0x90                // pointer to address is NULL (function will not work correctly)

// The Callback function is called, if certain events did occur.
// These Defines specify the event.
#define USBCAN_EVENT_INITHW             0                   // the USB-CANmodule has been initialized
#define USBCAN_EVENT_INITCAN            1                   // the CAN interface has been initialized
#define USBCAN_EVENT_RECIEVE            2                   // a new CAN message has been received
#define USBCAN_EVENT_STATUS             3                   // the error state in the module has changed
#define USBCAN_EVENT_DEINITCAN          4                   // the CAN interface has been deinitialized (UcanDeinitCan() was called)
#define USBCAN_EVENT_DEINITHW           5                   // the USB-CANmodule has been deinitialized (UcanDeinitHardware() was called)
#define USBCAN_EVENT_CONNECT            6                   // a new USB-CANmodule has been connected
#define USBCAN_EVENT_DISCONNECT         7                   // a USB-CANmodule has been disconnected
#define USBCAN_EVENT_FATALDISCON        8                   // a USB-CANmodule has been disconnected during operation

// CAN Error messages (is returned with UcanGetStatus() )
#define USBCAN_CANERR_OK                0x0000              // no error
#define USBCAN_CANERR_XMTFULL           0x0001              // Tx-buffer of the CAN controller is full
#define USBCAN_CANERR_OVERRUN           0x0002              // Rx-buffer of the CAN controller is full
#define USBCAN_CANERR_BUSLIGHT          0x0004              // Bus error: Error Limit 1 exceeded (refer to SJA1000 manual)
#define USBCAN_CANERR_BUSHEAVY          0x0008              // Bus error: Error Limit 2 exceeded (refer to SJA1000 manual)
#define USBCAN_CANERR_BUSOFF            0x0010              // Bus error: CAN controllerhas gone into Bus-Off state
#define USBCAN_CANERR_QRCVEMPTY         0x0020              // RcvQueue is empty
#define USBCAN_CANERR_QOVERRUN          0x0040              // RcvQueue overrun
#define USBCAN_CANERR_QXMTFULL          0x0080              // transmit queue is full
#define USBCAN_CANERR_REGTEST           0x0100              // Register test of the SJA1000 failed
#define USBCAN_CANERR_MEMTEST           0x0200              // Memory test failed

// USB error messages (is returned with UcanGetStatus() )
#define USBCAN_USBERR_OK                0x0000              // no error

// ABR and ACR for mode "receive all CAN messages"
#define USBCAN_AMR_ALL                  (DWORD) 0xffffffff
#define USBCAN_ACR_ALL                  (DWORD) 0x00000000

#define USBCAN_OCR_DEFAULT              0x1A

// definitions for CAN channels
#define USBCAN_CHANNEL_CH0              0
#define USBCAN_CHANNEL_CH1              1
#define USBCAN_CHANNEL_ANY              255 // only available for functions UcanCallbackFktEx, UcanReadCanMsgEx

// definitions for function UcanResetCanEx()
#define USBCAN_RESET_ALL                0x00000000  // no firmware reset
#define USBCAN_RESET_NO_STATUS          0x00000001  // not implemented in this version
#define USBCAN_RESET_NO_CANCTRL         0x00000002
#define USBCAN_RESET_NO_TXCOUNTER       0x00000004
#define USBCAN_RESET_NO_RXCOUNTER       0x00000008
#define USBCAN_RESET_NO_TXBUFFER_DLL    0x00000020
#define USBCAN_RESET_NO_TXBUFFER_FW     0x00000080
#define USBCAN_RESET_NO_RXBUFFER_CH     0x00000100
#define USBCAN_RESET_NO_RXBUFFER_DLL    0x00000200
#define USBCAN_RESET_NO_RXBUFFER_SYS    0x00000400
#define USBCAN_RESET_NO_RXBUFFER_FW     0x00000800
#define USBCAN_RESET_FIRMWARE           0xFFFFFFFF  // buffers, counters and CANCRTL will be reseted indirectly during firmware reset

// combinations of flags for UcanResetCanEx()
#define USBCAN_RESET_NO_COUNTER_ALL    (USBCAN_RESET_NO_TXCOUNTER | USBCAN_RESET_NO_RXCOUNTER)
#define USBCAN_RESET_NO_TXBUFFER_COMM  (USBCAN_RESET_NO_TXBUFFER_DLL | 0x00000040 | USBCAN_RESET_NO_TXBUFFER_FW)
#define USBCAN_RESET_NO_TXBUFFER_ALL   (0x00000010 | USBCAN_RESET_NO_TXBUFFER_COMM)
#define USBCAN_RESET_NO_RXBUFFER_COMM  (USBCAN_RESET_NO_RXBUFFER_DLL  | USBCAN_RESET_NO_RXBUFFER_SYS | USBCAN_RESET_NO_RXBUFFER_FW)
#define USBCAN_RESET_NO_RXBUFFER_ALL   (USBCAN_RESET_NO_RXBUFFER_CH0  | USBCAN_RESET_NO_RXBUFFER_COMM)
#define USBCAN_RESET_NO_BUFFER_COMM    (USBCAN_RESET_NO_TXBUFFER_COMM | USBCAN_RESET_NO_RXBUFFER_COMM)
#define USBCAN_RESET_NO_BUFFER_ALL     (USBCAN_RESET_NO_TXBUFFER_ALL  | USBCAN_RESET_NO_RXBUFFER_ALL)

#define USBCAN_RESET_ONLY_RXCHANNEL_BUFF    (0x0000FFFF & ~(USBCAN_RESET_NO_RXCOUNTER | USBCAN_RESET_NO_RXBUFFER_CH))
#define USBCAN_RESET_ONLY_STATUS            (0x0000FFFF & ~(USBCAN_RESET_NO_STATUS))


// Meaning of suffixes of defines USBCAN_RESET_NO_RXBUFFER_.. (used for function UcanResetCanEx() to reset Rx-Buffers or not)
//
//              CAN-            Firmware-       Kernel-         USBCAN32.DLL    USBCAN32.DLL
//              Controller:     Rx-Buffer       Rx-Buffer       Rx-Buffer       Rx-Channel-Buffer
//----------------------------------------------------------------------------------------------------------------------------
// Suffix:                      .._FW           .._SYS          .._DLL         .._CH
//   .._COMM =                 {~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~}
//   .._ALL  =                 {~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~}
//----------------------------------------------------------------------------------------------------------------------------
// Order-Nr.:
//
// GW-001:      +-----+                                                         +---------+
// GW-002:      | CH0 |                                                         |||||||||||
// 3004006:     +-----+ ----->  +---------+     +---------+     +---------+ --> +---------+ --> +--------------------+
//                              ||||||||||| --> ||||||||||| --> |||||||||||                     | UcanReadCanMsgEx() |
//              ....... ----->  +---------+     +---------+     +---------+ --> +---------+ --> +--------------------+
// 3004006:     . CH1 .                                                         |||||||||||
//              .......                                                         +---------+
//
//----------------------------------------------------------------------------------------------------------------------------
// Nr. of messages in buffer:   768             4096            1024            1024
//
// NOTE:
// If Rx-Buffers of Firmware, Kernel-Mode Driver and/or Rx-Buffer of DLL (suffix .._DLL) will be reseted,
// then CAN messages of both CAN-Channels (CH0 and CH1) may be deleted (lost for application).
//
// If UcanResetCanEx() is called with dwResetFlags_p = USBCAN_RESET_NO_RXBUFFER_COMM (for example), then
// only Rx-Buffer of CAN-Channel 0 or 1 will be deleted (as defined in parameter bChannel_p).


//---------------------------------------------------------------------------
// types
//---------------------------------------------------------------------------

// set structure alignement to 1 byte
#pragma pack(push,1)

// Typedef for the USB-CAN Handle
#ifndef UCHANDLE_DEFINED
    #define UCHANDLE_DEFINED
    typedef BYTE tUcanHandle;
#endif

// Typedef for the Callback function
typedef void (PUBLIC *tCallbackFkt) (tUcanHandle UcanHandle_p, BYTE bEvent_p);
typedef void (PUBLIC *tCallbackFktEx) (tUcanHandle UcanHandle_p, DWORD dwEvent_p, BYTE bChannel_p, void* pArg_p);

// Typedef for the Connection-Control function
typedef void (PUBLIC *tConnectControlFkt) (BYTE bEvent_p, DWORD dwParam_p);
typedef void (PUBLIC *tConnectControlFktEx) (DWORD dwEvent_p, DWORD dwParam_p, void* pArg_p);

// Structure for the CAN message (suitable for CAN messages according to spec. CAN2.0B)
typedef struct
{
    DWORD   m_dwID;                         // CAN Identifier
    BYTE    m_bFF;                          // CAN Frame format (BIT7=1: 29BitID / BIT6=1: RTR-Frame / BIT5=1: Tx echo)
    BYTE    m_bDLC;                         // CAN Data Length Code
    BYTE    m_bData[8];                     // CAN Data
    DWORD   m_dwTime;                       // Time in ms

    // NOTE:
    // Value of m_dwTime only is valid for received CAN messages. It is ignored for
    // CAN messages to send. Bits 0 until 23 contains time and bits 24 until 31 are
    // reserved.

} tCanMsgStruct;

// Structure with the stati (Function: UcanGetStatus())
typedef struct
{
    WORD    m_wCanStatus;                   // current CAN status
    WORD    m_wUsbStatus;                   // current USB status

} tStatusStruct;

// Structure with init parameters for function UcanInitCanEx() and UcanInitCanEx2()
typedef struct
{
    DWORD       m_dwSize;                   // [IN] size of this structure
    BYTE        m_bMode;                    // [IN] slecets the mode of CAN controller (see kUcanMode...)

    // Baudrate Registers for GW-001 or GW-002
    BYTE        m_bBTR0;                    // [IN] Bus Timing Register 0 (SJA1000 - use high byte USBCAN_BAUD_...)
    BYTE        m_bBTR1;                    // [IN] Bus Timing Register 1 (SJA1000 - use low  byte USBCAN_BAUD_...)

    BYTE        m_bOCR;                     // [IN] Output Controll Register of SJA1000 (should be 0x1A)
    DWORD       m_dwAMR;                    // [IN] Acceptance Mask Register (SJA1000)
    DWORD       m_dwACR;                    // [IN] Acceptance Code Register (SJA1000)

    // since version V3.00 - will be ignored from function UcanInitCanEx()
    DWORD       m_dwBaudrate;               // [IN] Baudrate Register for GW-006 or Multiport 3004006 (use USBCAN_BAUDEX_...)

} tUcanInitCanParam;

// Structure with the hardware properties of a USB-CANmodule (Function: UcanGetHardwareInf())
typedef struct
{
    BYTE        m_bDeviceNr;                // [OUT] device number of the USB-CANmodule
    tUcanHandle m_UcanHandle;               // [OUT] USB-CAN-Handle assigned by the DLL
    DWORD       m_dwReserved;               // [OUT] reserved

    // values only for CAN channel 0
    BYTE        m_bBTR0;                    // [OUT] Bus Timing Register 0 (SJA1000)
    BYTE        m_bBTR1;                    // [OUT] Bus Timing Register 1 (SJA1000)
    BYTE        m_bOCR;                     // [OUT] Output Control Register (SJA1000)
    DWORD       m_dwAMR;                    // [OUT] Acceptance Mask Register (SJA1000)
    DWORD       m_dwACR;                    // [OUT] Acceptance Code Register (SJA1000)

    // new values since 17.03.03 Version V2.16
    BYTE        m_bMode;                    // [OUT] mode of CAN controller (see kUcanMode...)
    DWORD       m_dwSerialNr;               // [OUT] serial number from USB-CANmodule

} tUcanHardwareInfo;

typedef struct
{
    DWORD       m_dwSize;                   // [IN]  size of this structure
    tUcanHandle m_UcanHandle;               // [OUT] USB-CAN-Handle assigned by the DLL
    BYTE        m_bDeviceNr;                // [OUT] device number of the USB-CANmodule
    DWORD       m_dwSerialNr;               // [OUT] serial number from USB-CANmodule
    DWORD       m_dwFwVersionEx;            // [OUT] version of firmware
    DWORD       m_dwReserved;

} tUcanHardwareInfoEx;

typedef struct
{
    DWORD       m_dwSize;                   // [IN]  size of this structure
    BYTE        m_bMode;                    // [OUT] slecets the mode of CAN controller (see kUcanMode...)
    BYTE        m_bBTR0;                    // [OUT] Bus Timing Register 0 (SJA1000 - use high byte USBCAN_BAUD_...)
    BYTE        m_bBTR1;                    // [OUT] Bus Timing Register 1 (SJA1000 - use low  byte USBCAN_BAUD_...)
    BYTE        m_bOCR;                     // [OUT] Output Controll Register of SJA1000 (should be 0x1A)
    DWORD       m_dwAMR;                    // [OUT] Acceptance Mask Register (SJA1000)
    DWORD       m_dwACR;                    // [OUT] Acceptance Code Register (SJA1000)
    DWORD       m_dwBaudrate;               // [OUT] Baudrate Register for GW-006 or Multiport 3004006 (use USBCAN_BAUDEX_...)
    BOOL        m_fCanIsInit;               // [OUT] is TRUE if CAN interface was initialized, otherwise FALSE
    WORD        m_wCanStatus;               // [OUT] CAN status (same as received from function UcanGetStatus..())

} tUcanChannelInfo;

typedef BYTE tUcanMode;                     // definitions of CAN modes
#define kUcanModeNormal             0x00    // normal mode (send and reciceive)
#define kUcanModeListenOnly         0x01    // listen only mode (only reciceive)
#define kUcanModeTxEcho             0x02    // CAN messages which was sent will be received at UcanReadCanMsg..
#define kUcanModeRxOrderCh          0x04    // reserved (not implemented in this version)


// structure with transfered packet informations
typedef struct
{
    WORD m_wSentMsgCount;                   // counter of sent CAN messages
    WORD m_wRecvdMsgCount;                  // counter of received CAN messages

} tUcanMsgCountInfo;

// version types for function UcanGetVersionEx()
typedef enum
{
    kVerTypeUserDll  = 0x0001,              // returns the version of USBCAN32.DLL
    kVerTypeSysDrv   = 0x0002,              // returns the version of USBCAN.SYS (not supported in this version)
    kVerTypeFirmware = 0x0003               // returns the version of firmware in hardware (not supported, use function UcanGetFwVersion)

} tUcanVersionType;

#pragma pack(pop)


//---------------------------------------------------------------------------
// function prototypes
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------
//
// Function:    UcanGetVersion()
//
// Description: returns software version of USBCAN32.DLL
//
// Parameters:  none
//
// Returns:     software version
//                  format: Bits 0-7:   least significant version number (binary)
//                          Bits 8-15:  most significant version number (binary)
//                          Bits 16-30: reserved
//                          Bit 31:     1 = customer specific version
//
//---------------------------------------------------------------------------

DWORD PUBLIC UcanGetVersion (void);


//---------------------------------------------------------------------------
//
// Function:    UcanGetVersionEx()
//
// Description: returns software version of different software modules
//
// Parameters:  VerType_p   = [IN] which version should be returned
//                                 kVerTypeUserDll returnes Version of USBCAN32.DLL
//                                 No more versions available at this time.
//                                 (see enum tUcanVersionType for more informations)
//
// Returns:     software version
//                  format: Bit 0-7:    Version
//                          Bit 8-15:   Revision
//                          Bit 16-31:  Release
//
// NOTE: If returned version is zero, then value of VerType_p
//       was unknown or not supported.
//
//---------------------------------------------------------------------------

DWORD PUBLIC UcanGetVersionEx (tUcanVersionType VerType_p);


//---------------------------------------------------------------------------
//
// Function:    UcanGetFwVersion()
//
// Description: returns version of the firmware within USB-CANmodul
//
// Parameters:  UcanHandle_p    = [IN] USBCAN handle
//
// Return:      DWORD           = version in extended format (see UcanGetVersionEx)
//
//---------------------------------------------------------------------------

DWORD PUBLIC UcanGetFwVersion (tUcanHandle UcanHandle_p);


//---------------------------------------------------------------------------
//
// Function:    UcanInitHwConnectControl(), UcanInitHwConnectControlEx
//
// Description: Initializes the Hardware-Connection-Control function
//
// Parameters:  fpConnectControlFkt_p   = [IN] address to Hardware-Connection-Control function
//
//              fpConnectControlFktEx_p = [IN] address of the new Hardware-Connection-Control function
//                                             NULL: no Callback function is used
//              pCallbackArg_p          = [IN] additional user defined parameter for callback function
//
// NOTE:    Do not set function pointer of type tConnectControlFkt to fpConnectControlFktEx_p and
//          do not set function pointer of type tConnectControlFktEx to fpConnectControlFkt_p !
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_RESOURCE
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanInitHwConnectControl (tConnectControlFkt fpConnectControlFkt_p);
BYTE PUBLIC UcanInitHwConnectControlEx (tConnectControlFktEx fpConnectControlFktEx_p, void* pCallbackArg_p);


//---------------------------------------------------------------------------
//
// Function:    UcanDeinitHwConnectControl()
//
// Description: Deinitializes the Hardware-Connection-Control function
//
// Parameters:  none
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanDeinitHwConnectControl (void);


//---------------------------------------------------------------------------
//
// Function:    UcanInitHardware(), UcanInitHardwareEx()
//
// Description: Initializes a USB-CANmodule with the device number x
//
// Parameters:  pUcanHandle_p   = [OUT] address pointing to the variable for the USB-CAN-Handle
//                                      should not be ZERO!
//              bDeviceNr_p     = [IN]  device number of the USB-CANmodule
//                                      valid values: 0 through 254
//                                      USBCAN_ANY_MODULE: the first module that is found will be used
//              fpCallbackFkt_p = [IN]  address of the Callback function
//                                      NULL: no Callback function is used
//
//              fpCallbackFktEx_p   = [IN] address of the new callback function
//                                         NULL: no Callback function is used
//              pCallbackArg_p      = [IN] additional user defined parameter for callback function
//
// NOTE:    Do not set function pointer of type tCallbackFkt to fpCallbackFktEx_p and
//          do not set function pointer of type tCallbackFktEx to fpCallbackFkt_p !
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_HWINUSE
//                  USBCAN_ERR_ILLHW
//                  USBCAN_ERR_MAXMODULES
//                  USBCAN_ERR_RESOURCE
//                  USBCAN_ERR_ILLVERSION
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanInitHardware (tUcanHandle* pUcanHandle_p, BYTE bDeviceNr_p, tCallbackFkt fpCallbackFkt_p);
BYTE PUBLIC UcanInitHardwareEx (tUcanHandle* pUcanHandle_p, BYTE bDeviceNr_p, tCallbackFktEx fpCallbackFktEx_p, void* pCallbackArg_p);


//---------------------------------------------------------------------------
//
// Function:    UcanGetModuleTime()
//
// Description: Returns the current time stamp of USB-CANmodul.
//              NOTE: Some milliseconds are pased if function returnes.
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pdwTime_p       = [OUT] pointer to DWORD receiving time stamp
//                                      can not be NULL
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_ILLPARAM
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanGetModuleTime (tUcanHandle UcanHandle_p, DWORD* pdwTime_p);


//---------------------------------------------------------------------------
//
// Function:    UcanGetHardwareInfo()
//
// Description: Returns the hardware information of an initialized USB-CANmodul
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pHwInfo_p       = [OUT] pointer to hardware info structure
//                                      can not be NULL
//
//              pCanInfoCh0_p   = [OUT] pointer to CAN channel 0 info structure
//              pCanInfoCh1_p   = [OUT] pointer to CAN channel 1 info structure
//                                      pCanInfoCh0_p and pCanInfoCh1_p can be NULL
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_ILLPARAM
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanGetHardwareInfo (tUcanHandle UcanHandle_p, tUcanHardwareInfo* pHwInfo_p);
BYTE PUBLIC UcanGetHardwareInfoEx2 (tUcanHandle UcanHandle_p, tUcanHardwareInfoEx* pHwInfo_p, tUcanChannelInfo* pCanInfoCh0_p, tUcanChannelInfo* pCanInfoCh1_p);


//---------------------------------------------------------------------------
//
// Function:    UcanInitCan(), UcanInitCanEx()
//
// Description: Initializes the CAN interface on the USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              bBTR0_p         = [IN]  Baudrate Register 0 (SJA1000)
//              bBTR1_p         = [IN]  Baudrate Register 1 (SJA1000)
//              dwAMR_p         = [IN]  Acceptance Filter Mask (SJA1000)
//              dwACR_p         = [IN]  Acceptance Filter Code (SJA1000)
//
//              pInitCanParam_p = [IN]  pointer to init parameter structure
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_RESOURCE
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_REGTST
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanInitCan (tUcanHandle UcanHandle_p, BYTE bBTR0_p, BYTE bBTR1_p, DWORD dwAMR_p, DWORD dwACR_p);
BYTE PUBLIC UcanInitCanEx (tUcanHandle UcanHandle_p, tUcanInitCanParam* pInitCanParam_p);
BYTE PUBLIC UcanInitCanEx2 (tUcanHandle UcanHandle_p, BYTE bChannel_p, tUcanInitCanParam* pInitCanParam_p);


//---------------------------------------------------------------------------
//
// Function:    UcanSetBaudrate(), UcanSetBaudrateEx()
//
// Description: Modifies the baudrate settings of the USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              bBTR0_p         = [IN]  Baudrate Register 0 (GW-001/002 - GW-006 or Multiport
//                                      3004006 only standard values)
//              bBTR1_p         = [IN]  Baudrate Register 1 (GW-001/002 - GW-006 or Multiport
//                                      3004006 only standard values)
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//              dwBaudrate_p    = [IN]  Baudrate Register of GW-006 or Multiport 3004006
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanSetBaudrate (tUcanHandle UcanHandle_p, BYTE bBTR0_p, BYTE bBTR1_p);
BYTE PUBLIC UcanSetBaudrateEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, BYTE bBTR0_p, BYTE bBTR1_p, DWORD dwBaudrate_p);


//---------------------------------------------------------------------------
//
// Function:    UcanSetAcceptance(), UcanSetAcceptanceEx()
//
// Description: Modifies the Acceptance Filter settings of the USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              dwAMR_p         = [IN]  Acceptance Filter Mask (SJA1000)
//              dwACR_p         = [IN]  Acceptance Filter Code (SJA1000)
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanSetAcceptance (tUcanHandle UcanHandle_p, DWORD dwAMR_p, DWORD dwACR_p);
BYTE PUBLIC UcanSetAcceptanceEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, DWORD dwAMR_p, DWORD dwACR_p);


//---------------------------------------------------------------------------
//
// Function:    UcanResetCan(), UcanResetCanEx()
//
// Description: Resets the CAN interface (Hardware-Reset, empty buffer, ...)
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//              dwResetFlags_p  = [IN]  flags defines what should be reseted
//                                      (see USBCAN_RESET_...)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanResetCan (tUcanHandle UcanHandle_p);
BYTE PUBLIC UcanResetCanEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, DWORD dwResetFlags_p);


//---------------------------------------------------------------------------
//
// Function:    UcanReadCanMsg()
//
// Description: Reads one or more CAN messages
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pCanMsg_p       = [OUT] pointer to the CAN message structure
//
//              pbChannel_p     = [IN/OUT] pointer CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1, USBCAN_CHANNEL_ANY)
//                                         pointer must not be NULL
//                                         if INPUT is USBCAN_CHANNEL_ANY the OUTPUT will be the read CAN channel
//              pdwCount_p      = [IN/OUT] pointer to number of received CAN messages
//                                         if NULL only one CAN message will be read
//                                         INPUT:  *pdwCount_p contains max number of CAN messages which should be read
//                                         OUTPUT: *pdwCount_p contains real number of CAN messages was read
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_ILLPARAM
//                  USBCAN_WARN_NODATA
//                  USBCAN_WARN_SYS_RXOVERRUN
//                  USBCAN_WARN_DLL_RXOVERRUN
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanReadCanMsg (tUcanHandle UcanHandle_p, tCanMsgStruct* pCanMsg_p);
BYTE PUBLIC UcanReadCanMsgEx (tUcanHandle UcanHandle_p, BYTE* pbChannel_p, tCanMsgStruct* pCanMsg_p, DWORD* pdwCount_p);


//---------------------------------------------------------------------------
//
// Function:    UcanWriteCanMsg(), UcanWriteCanMsgEx()
//
// Description: Sends one or more CAN messages
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pCanMsg_p       = [IN]  pointer to the CAN message structure
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//              pdwCount_p      = [IN/OUT] pointer to number of CAN messages to write
//                                         if NULL only one CAN message will be written
//                                         INPUT:  *pdwCount_p contains number of CAN messages which should be written
//                                         OUTPUT: *pdwCount_p contains real number of CAN messages was written
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_ILLPARAM
//                  USBCAN_ERR_DLL_TXFULL
//                  USBCAN_WARN_FW_TXOVERRUN
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanWriteCanMsg (tUcanHandle UcanHandle_p, tCanMsgStruct* pCanMsg_p);
BYTE PUBLIC UcanWriteCanMsgEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, tCanMsgStruct* pCanMsg_p, DWORD* pdwCount_p);


//---------------------------------------------------------------------------
//
// Function:    UcanGetStatus(), UcanGetStatusEx()
//
// Description: Returns the state of the USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pStatus_p       = [OUT] pointer to Status structure
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_ILLPARAM
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanGetStatus (tUcanHandle UcanHandle_p, tStatusStruct* pStatus_p);
BYTE PUBLIC UcanGetStatusEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, tStatusStruct* pStatus_p);


//---------------------------------------------------------------------------
//
// Function:    UcanGetMsgCountInfo(), UcanGetMsgCountInfoEx()
//
// Description: Reads the packet information from USB-CANmodule (counter of
//              received and sent CAN messages).
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              pMsgCountInfo_p = [OUT] pointer to message counter information structure
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanGetMsgCountInfo (tUcanHandle UcanHandle_p, tUcanMsgCountInfo* pMsgCountInfo_p);
BYTE PUBLIC UcanGetMsgCountInfoEx (tUcanHandle UcanHandle_p, BYTE bChannel_p, tUcanMsgCountInfo* pMsgCountInfo_p);


//---------------------------------------------------------------------------
//
// Function:    UcanDeinitCan()
//
// Description: Shuts down the CAN interface on the USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1)
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//                  USBCAN_ERR_CANNOTINIT
//                  USBCAN_ERR_BUSY
//                  USBCAN_ERR_IOFAILED
//                  USBCAN_ERRCMD_NOTEQU
//                  USBCAN_ERRCMD_ILLCMD
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanDeinitCan (tUcanHandle UcanHandle_p);
BYTE PUBLIC UcanDeinitCanEx (tUcanHandle UcanHandle_p, BYTE bChannel_p);


//---------------------------------------------------------------------------
//
// Function:    UcanDeinitHardware()
//
// Description: Deinitializes a USB-CANmodule
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//
// Returns:     result of the function
//                  USBCAN_SUCCESSFUL
//                  USBCAN_ERR_MAXINSTANCES
//                  USBCAN_ERR_ILLHANDLE
//
//---------------------------------------------------------------------------

BYTE PUBLIC UcanDeinitHardware (tUcanHandle UcanHandle_p);


//---------------------------------------------------------------------------
//
// Callback functions
//
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//
// Function:    UcanCallbackFkt(), UcanCallbackFktEx()
//
// Description: Is called from the USBCAN32.DLL if a working event occured.
//
// Parameters:  UcanHandle_p    = [IN]  USB-CAN-Handle
//                                      Handle, which is returned by the function UcanInitHardware()
//              bEvent_p        = [IN]  event
//                  USBCAN_EVENT_INITHW
//                  USBCAN_EVENT_INITCAN
//                  USBCAN_EVENT_RECIEVE
//                  USBCAN_EVENT_STATUS
//                  USBCAN_EVENT_DEINITCAN
//                  USBCAN_EVENT_DEINITHW
//
//              bChannel_p      = [IN]  CAN channel (USBCAN_CHANNEL_CH0 or USBCAN_CHANNEL_CH1, USBCAN_CHANNEL_ANY)
//              pArg_p          = [IN]  additional parameter
//                                      Parameter which was defined with UcanInitHardwareEx()
//
// Returns:     none
//
//---------------------------------------------------------------------------

void PUBLIC UcanCallbackFkt (tUcanHandle UcanHandle_p, BYTE bEvent_p);
void PUBLIC UcanCallbackFktEx (tUcanHandle UcanHandle_p, DWORD bEvent_p, BYTE bChannel_p, void* pArg_p);


//---------------------------------------------------------------------------
//
// Function:    UcanConnectControlFkt(), UcanConnectControlFktEx()
//
// Description: Is called from the USBCAN32.DLL if a plug & play event occured.
//
// Parameters:  bEvent_p    = [IN]  event
//                  USBCAN_EVENT_CONNECT
//                  USBCAN_EVENT_DISCONNECT
//                  USBCAN_EVENT_FATALDISCON
//              dwParam_p   = [IN]  additional parameter (depends on bEvent_p)
//                  USBCAN_EVENT_CONNECT:       always 0
//                  USBCAN_EVENT_DISCONNECT.    always 0
//                  USBCAN_EVENT_FATALDISCON:   USB-CAN-Handle of the disconnected module
//
//              pArg_p      = [IN]  additional parameter
//                                  Parameter which was defined with UcanInitHardwareEx()
//
// Returns:     none
//
//---------------------------------------------------------------------------

void PUBLIC UcanConnectControlFkt (BYTE bEvent_p, DWORD dwParam_p);
void PUBLIC UcanConnectControlFktEx (DWORD dwEvent_p, DWORD dwParam_p, void* pArg_p);


#ifdef __cplusplus
} // von extern "C"
#endif


#endif //__USBCAN32_H__
